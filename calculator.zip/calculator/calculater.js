  function one()
  {
    input.value = input.value + "1";
  }

  function two()
  {
    input.value = input.value + "2";
  }

   function three()
  {
    input.value = input.value + "3";
  }

  function plus()
  {
    p = "+";
    input.value = input.value + p;
  }

   function four()
  {
    input.value = input.value + "4";
  }

  function five()
  {
    input.value = input.value + "5";
  }

  function six()
  {
    input.value = input.value + "6";
  }

  function minus()
  {  
    m = "-";
    input.value = input.value + m;
  }

  function seven()
  {
    input.value = input.value + "7";
  }

  function eight()
  {
    input.value = input.value + "8";
  }

  function nine()
  {
    input.value = input.value + "9";
  }

  function multi()
  { 
    g = "*";
    input.value = input.value + g;
  }

  function c()
  {
    input.value = "";
  }

  function zero()
  {
    input.value = input.value + "0";
  }

  function divide()
  {
    d = "/";
    input.value = input.value + d;
  }

  function equal()
  {
    w = input.value
    input.value =  eval(w);
  }